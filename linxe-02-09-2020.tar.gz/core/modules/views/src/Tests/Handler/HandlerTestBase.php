<?php

namespace Drupal\views\Tests\Handler;

@trigger_error('\Drupal\views\Tests\Handler\HandlerTestBase is deprecated in Drupal 8.4.0 and will be removed before Drupal 9.0.0. Instead, use \Drupal\Tests\views\Functional\ViewTestBase', E_USER_DEPRECATED);

use Drupal\views\Tests\ViewTestBase;

/**
 * @deprecated in Drupal 8.4.0 and will be removed before Drupal 9.0.0.
 *   Use \Drupal\Tests\views\Functional\ViewTestBase.
 */
abstract class HandlerTestBase extends ViewTestBase {

}
